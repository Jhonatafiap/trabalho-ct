import java.util.Scanner;

public class Ex4 {
	
	public static void main(String[] args) {
		float real;
		float dolar;
		float result;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Quanto vale o dolar hoje?");
		dolar = entrada.nextFloat();
		
		System.out.println("Quantos reais voc� tem?");
		real = entrada.nextFloat();
		
		result = dolar * real;
		
		System.out.println("Seus reais em dol�res s�o :" + result);
		
		entrada.close();
	}
}
