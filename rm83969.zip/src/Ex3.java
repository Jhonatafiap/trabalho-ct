import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		int n;
		int n2;
		int n3;
		int n4;
		int result;
		int result2;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Qual o primeiro numero?");
		n = entrada.nextInt();
		
		System.out.println("Qual o segundo numero?");
		n2 = entrada.nextInt();
		
		System.out.println("Qual o terceiro numero?");
		n3 = entrada.nextInt();
		
		System.out.println("Qual o quarto numero?");
		n4 = entrada.nextInt();
		
		result = n + n3;
		result2 = n2 + n4;
		
		System.out.println("O resultado da soma do primero + o terceiro numero �: " + result);
		System.out.println("O resultado da soma do segundo + o quarto numero �: " + result2);
		
		entrada.close();
	}

}
