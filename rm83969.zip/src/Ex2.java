import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		int n;
		int n2;
		int n3;
		int result;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Qual o primeiro numero?");
		n = entrada.nextInt();
		
		System.out.println("Qual o segundo numero?");
		n2 = entrada.nextInt();
		
		System.out.println("Qual o terceiro numero?");
		n3 = entrada.nextInt();
		
		result = (n + n2 + n3 ) * (n + n2 + n3 );
		
		System.out.println("O resultado � " + result);
		
		entrada.close();
	}

}
