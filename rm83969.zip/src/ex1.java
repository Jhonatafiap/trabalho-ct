import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		int n;
		int result;
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Qual o numero?");
		n = entrada.nextInt();
		
		result = n * n;
		
		System.out.println("O resultado � " + result);
		
		entrada.close();
	}

}
