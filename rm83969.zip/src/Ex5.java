import java.util.Scanner;

public class Ex5 {
	public static void main(String[] args) {
		
		float valor;
		float gas;
		float result;
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Quanto custa o litro gasolina?");
		valor = entrada.nextFloat();
		
		System.out.println("Quanto voc� vai por de gasolina ?");
		gas = entrada.nextFloat();
		
		result = gas / valor;
		
		System.out.println("Voc� vai ter " + result + "l de gasolina");
		
		entrada.close();
	}
}
